#!/bin/bash

for run in {1..10}; do 
	./$1 $2
done
