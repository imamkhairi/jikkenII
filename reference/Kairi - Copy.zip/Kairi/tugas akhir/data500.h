#ifndef DATA500_H
#define DATA500_H

extern void Input500d(int*, int);
extern void Input500s(int*, int);
#endif

