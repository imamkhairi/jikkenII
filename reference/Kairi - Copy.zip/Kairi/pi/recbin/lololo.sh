#!/bin/bash
echo "success total percentage gosa"

let myval=10000
echo $myval


for i in {1..10}; 
    do 
        bin/kadai1 10000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 50000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 100000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 500000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 1000000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 5000000
        sleep .90;
    done

for i in {1..10}; 
    do 
        bin/kadai1 10000000
        sleep .90;
    done
       
for i in {1..10}; 
    do 
        bin/kadai1 50000000
        sleep .90;
    done
       
       

       
