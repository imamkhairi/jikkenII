#ifndef DATA100_H
#define DATA100_H

extern void Input100d(int*, int);
extern void Input100s(int*, int);
#endif

