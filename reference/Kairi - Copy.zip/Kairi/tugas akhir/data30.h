#ifndef DATA30
#define DATA30

extern void Input30(int*, int);
extern void Input50(int*, int);
extern void Input70(int*, int);
extern void Input100(int*, int);

#endif

