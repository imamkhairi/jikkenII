#ifndef DATA1000_H
#define DATA1000_H

extern void Input1000d(int*, int);
extern void Input1000s(int*, int);
#endif

