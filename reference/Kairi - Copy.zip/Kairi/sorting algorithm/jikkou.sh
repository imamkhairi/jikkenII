#!/bin/bash 

./bin/bubble data/data1.dat 100